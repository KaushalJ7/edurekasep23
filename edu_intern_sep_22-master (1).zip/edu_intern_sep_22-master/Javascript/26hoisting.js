a = 10;
var b = 20;

console.log(add(a,b));

function add(a,b){
    return a+b
}

var a;
//////////
var a;
var b;
function add(a,b){
    return a+b
}

a = 10
b = 20;
console.log(add(a,b));