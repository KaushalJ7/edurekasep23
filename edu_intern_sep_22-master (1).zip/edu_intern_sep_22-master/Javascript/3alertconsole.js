alert >>>> Notification
console >>>> debugging
prompt >> to take input from user
confirm >> weather yes or no


alert("Form Submitted Successfully")
alert('No Slot left');

confirm('Do you want to leave')
true
confirm('Do you want to leave')
false
var a = confirm('Do you want to leave')
a
true

prompt('What is your name')
'Nikita'
prompt('What is your age')
'10'

var age = prompt('What is your age')
age
'10'

var a = prompt('Enter First Value');
var b = prompt('Enter Second Value');
alert(Number(a)+Number(b))