es5
> Ecma Script 5
es6
> Ecma Script 6

//////////////////////

String >>> "Hiii" 'hello' '10' "true" `Test`  "10hi$"
Number >>> 10 78676786 878.332 .35353
Boolean >> true false

//es5
var a = 10;
var b = "Hi";
var c = true;

typeof(a)
'number'
typeof(b)
'string'
typeof(c)
'boolean'

var d = "20"
typeof(d)
'string'
var e = 'test'
typeof(e)
'string'
var f = 10.3435435
typeof(f)
'number'


var a = 10
var b = 20
a+b (addition)
30
a-b
-10
b-a
10
a*b
200
a/b
0.5
b/a
2
b%a
0

2%4
2
3%4
3
4%4
0

var a = "Hiii"
var b = "JavaScript"

a+b (concat)
'HiiiJavaScript'
a-b
NaN (Not a number)
a*b
NaN
a/b
NaN
a%b
NaN


var a = "Hiii"
var b = 10

a+b
'Hiii10'

string + string = string
string + number = string
number + string = string
number + number = number

var a = "Hiii"
var b = 10
a-b
NaN
b-a
NaN

"10"+20+30
"1020"+30
"102030"

10+"20"+30
"1020"+30
"102030"

10+20+"30"
30+"30"
"3030"


"10"+20+30-1
"102030"-1
102029

10+"20"+30-1
102029

10+20+"30"-1
3029


10+20+"30"-1
3029

"10a"-1
NaN

"hi"-1
NaN

"10"-1
9

"5"*"2"
10

"5"*"2a"
NaN

10/"3"
3.3333333333333335

"10"/"3a"
NaN

"10"+1
'101'



