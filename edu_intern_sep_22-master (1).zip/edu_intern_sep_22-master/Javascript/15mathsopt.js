Math.random()
0.09429066464190394
Math.random()
0.5155318351939298
Math.random()
0.29094252811400345
Math.random()*100
67.32095954171433
Math.random()*100000
60287.06414973233

Math.random()*30
17.048097182120518
Math.random()*30
4.718945293279193

Math.floor(10.1)
10
Math.floor(10.3)
10
Math.floor(10.9)
10
Math.ceil(10.1)
11
Math.ceil(10.5)
11
Math.ceil(10.9)
11

Math.round(10.1)
10
Math.round(10.4)
10
Math.round(10.7)
11
Math.round(10.9)
11


Math.floor(Math.random()*100000)
45438
Math.floor(Math.random()*100000)
35877
Math.floor(Math.random()*100000)
38597


Math.floor(Math.random()*(max-min))+min

Math.floor(Math.random()*(52-23))+23
42
Math.floor(Math.random()*(52-23))+23
37
Math.floor(Math.random()*(52-23))+23
30
Math.floor(Math.random()*(52-23))+23
39

Math.sin(1)
0.8414709848078965
Math.cos(2)
-0.4161468365471424
Math.tan(2)
-2.185039863261519
Math.log(1)
0
Math.log(0)
-Infinity
Math.pow(2,2)
4
Math.pow(2,3)
8
Math.E
2.718281828459045
Math.PI
3.141592653589793

Math.PI.toFixed(3)
'3.142'
Number(Math.PI.toFixed(3))
3.142
Number(Math.PI.toFixed(4))
3.1416

Math.sqrt(4)
2