let myObj = require('./first');
//import myObj from './first';

console.log(myObj.user);
console.log(myObj.calc.sum(7,9))

/*
[
  { uname: 'Alvin', city: 'Boston' },
  { uname: 'Priya', city: 'Paris' }
]
16
*/