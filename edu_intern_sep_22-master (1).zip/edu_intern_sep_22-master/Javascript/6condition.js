// all the conditional operaters always return boolean output
= // assignment
== // compare the data
=== // compare the data and data type

var a =  10 // assignment
var b = "10"
var c = 20
var d = 10

a == b // it compare the data
true
a == c 
false

a === b // it compare the data & data type
false
a === c
false


a == d
true
a == d
true

var e = true
var f = 1
e == f
true
e === f
false

10 >5
true
5< 10
true
10> 20
false
10 != 20
true
10 >= 5
true
10 <= 5
false

// Negation //
var a = true;
!a
false

var a = false;
!a
true

var a = 1
!a

var a = 1
!a
false

var a = 0
!a
true


var a = -1
!a
false
var a = "Hii"
undefined
!a
false

truthy >> any number except 0 weather +ve or -ve, true, any string
falsy >> 0, false, null, undefined